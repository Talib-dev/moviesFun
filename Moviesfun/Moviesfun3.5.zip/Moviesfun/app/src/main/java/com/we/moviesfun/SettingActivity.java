package com.we.moviesfun;

public class SettingActivity {
}
