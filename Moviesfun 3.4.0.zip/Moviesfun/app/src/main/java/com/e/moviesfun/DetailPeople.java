package com.e.moviesfun;

import android.graphics.Bitmap;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.e.moviesfun.API.Client;
import com.e.moviesfun.API.Service;
import com.e.moviesfun.model.PeopleInfo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailPeople extends AppCompatActivity {

    ImageView imageView;
    TextView name, dateOfbirth, placeOfBirth, biography;
    private int mPersonId;

    Call<PeopleInfo> mPersonDetailsCall;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_people);

        imageView = (ImageView) findViewById(R.id.iv_profile_photo);
        name = findViewById(R.id.tv_people_name);
        dateOfbirth = findViewById(R.id.tv_people_age);
        placeOfBirth = findViewById(R.id.tv_place_of_birth);
        biography = findViewById(R.id.tv_biography);


        mPersonId = getIntent().
                getExtras().getInt("PEOPLE_ID");
        Toast.makeText(this, "" + mPersonId, Toast.LENGTH_SHORT).show();



        loadData();
    }




        void loadData(){

            Service apiService = Client.getClient().create(Service.class);
            mPersonDetailsCall = apiService.
                    getpersonDetail(mPersonId, BuildConfig.THE_MOVIE_DB_API_TOKEN);
            mPersonDetailsCall.enqueue(new Callback<PeopleInfo>() {
                @Override
                public void onResponse(Call<PeopleInfo> call, Response<PeopleInfo> response) {

                    try {
                        String name = response.body().getName();
                        Toast.makeText(DetailPeople.this, ""+name, Toast.LENGTH_SHORT).show();
//                        castTextView.setText("Cast");
//                        castRecyclerView.setAdapter(new MovieCastAdapter(getApplicationContext(),
//                                casts));
//                        castRecyclerView.smoothScrollToPosition(0);
                    } catch(NullPointerException e)
                    {
                        System.out.print("NullPointerException caught");
                    }

//                if (!response.isSuccessful()) {
//                    mMovieCreditsCall = call.clone();
//                    mMovieCreditsCall.enqueue(this);
//                    return;
//                }
//
//                if (response.body() == null) return;
//                if (response.body().getCasts() == null) return;
//
//                for (MovieCast castBrief : response.body().getCasts()) {
//                    if (castBrief != null && castBrief.getName() != null)
//                        castList.add(castBrief);
//                }
//
//                if (!castList.isEmpty())
//                    mCastTextView.setVisibility(View.VISIBLE);
//                mCastAdapter.notifyDataSetChanged();
                }

                @Override
                public void onFailure(Call<PeopleInfo> call, Throwable t) {

                }
            });



        }



}





