package com.e.moviesfun.Activities.ui;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.e.moviesfun.R;
import com.e.moviesfun.home.HomeBottomNavigaton;

public class SplaceScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splace);


        new Handler().postDelayed(new Runnable() {


            @Override
            public void run() {
                Intent i = new Intent(SplaceScreen.this, HomeBottomNavigaton.class);
                startActivity(i);

                // close this activity
                finish();
            }
        }, 3000);

    }
}
