package com.e.moviesfun;

public class SettingActivity {
}
